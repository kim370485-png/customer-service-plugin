@echo off
chcp 65001 >nul
title 飞猪客服工具箱 - 安装程序

echo.
echo ============================================
echo   飞猪客服工具箱 - 自动安装程序
echo ============================================
echo.

:: 定义安装目录
set "INSTALL_DIR=%LOCALAPPDATA%\FliggyToolbox"

:: 复制扩展文件到固定位置
echo [1/2] 正在复制扩展文件...
if exist "%INSTALL_DIR%" (
    rmdir /s /q "%INSTALL_DIR%"
)
xcopy /e /i /q "%~dp0." "%INSTALL_DIR%" /exclude:"%~dp0exclude.txt" >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo [错误] 复制文件失败，请检查是否有权限。
    echo 尝试以管理员身份运行此脚本。
    pause
    exit /b 1
)
echo [完成] 文件已复制到 %INSTALL_DIR%

:: 写入注册表（HKCU，不需要管理员权限）
echo.
echo [2/2] 正在注册 Chrome 扩展策略...

:: 先清空旧的 ExtensionInstallForcelist
reg delete "HKCU\Software\Policies\Google\Chrome\ExtensionInstallForcelist" /f >nul 2>&1

:: 添加当前扩展到 HKCU
reg add "HKCU\Software\Policies\Google\Chrome\ExtensionInstallForcelist" /v "1" /t REG_SZ /d "%INSTALL_DIR%\manifest.json" /f >nul 2>&1
if %ERRORLEVEL% EQU 0 (
    echo [完成] 扩展策略已写入。
) else (
    echo [警告] 写入策略失败，但不影响手动安装。
)

:: 同时写入 ExtensionSettings（更宽松的策略）
reg add "HKCU\Software\Policies\Google\Chrome\ExtensionSettings\fliggy_toolbox" /v "installation_mode" /t REG_SZ /d "force_installed" /f >nul 2>&1
reg add "HKCU\Software\Policies\Google\Chrome\ExtensionSettings\fliggy_toolbox" /v "update_url" /t REG_SZ /d "file:///%INSTALL_DIR:\=/%/updates.xml" /f >nul 2>&1

echo.
echo ============================================
echo   安装完成！请按以下步骤在 Chrome 中启用：
echo ============================================
echo.
echo   1. 打开 Chrome，地址栏输入：chrome://extensions
echo   2. 右上角打开"开发者模式"开关
echo   3. 点击左上角"加载已解压的扩展程序"
echo   4. 选择以下文件夹：
echo.
echo      %INSTALL_DIR%
echo.
echo   5. 点击"选择文件夹"完成安装
echo.
echo ============================================
echo.

:: 打开安装目录方便用户复制路径
explorer "%INSTALL_DIR%"

:: 打开 Chrome 扩展页面
start chrome "chrome://extensions"

echo 已为您打开扩展目录和 Chrome 扩展页面。
echo 如果安装后扩展没有自动启用，请刷新 Chrome 页面。
echo.
pause
