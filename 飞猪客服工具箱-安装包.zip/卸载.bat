@echo off
chcp 65001 >nul
title 飞猪客服工具箱 - 卸载程序

echo.
echo ============================================
echo   飞猪客服工具箱 - 卸载程序
echo ============================================
echo.

set "INSTALL_DIR=%LOCALAPPDATA%\FliggyToolbox"

:: 删除扩展文件
echo [1/2] 正在删除扩展文件...
if exist "%INSTALL_DIR%" (
    rmdir /s /q "%INSTALL_DIR%"
    echo [完成] 文件已删除。
) else (
    echo [跳过] 扩展目录不存在。
)

:: 删除注册表策略
echo [2/2] 正在清理注册表...
reg delete "HKCU\Software\Policies\Google\Chrome\ExtensionInstallForcelist" /v "1" /f >nul 2>&1
reg delete "HKCU\Software\Policies\Google\Chrome\ExtensionSettings\fliggy_toolbox" /f >nul 2>&1
echo [完成] 注册表已清理。

echo.
echo ============================================
echo   卸载完成！
echo ============================================
echo.
echo 请在 Chrome 扩展页面 (chrome://extensions) 中
echo 点击"移除"按钮来移除扩展。
echo.

:: 打开 Chrome 扩展页面
start chrome "chrome://extensions"

pause
